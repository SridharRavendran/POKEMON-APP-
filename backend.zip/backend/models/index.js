const { Sequelize, DataTypes } = require('sequelize');
const sequelize = new Sequelize('postgres://user:password@localhost:5432/pokemon_db');

const Pokemon = sequelize.define('Pokemon', {
    id: { type: DataTypes.INTEGER, primaryKey: true },
    name: { type: DataTypes.STRING, allowNull: false },
    image: { type: DataTypes.STRING },
    type: { type: DataTypes.STRING },
    height: { type: DataTypes.INTEGER },
    weight: { type: DataTypes.INTEGER }
});

const Stat = sequelize.define('Stat', {
    pokemon_id: { type: DataTypes.INTEGER, references: { model: Pokemon, key: 'id' } },
    hp: { type: DataTypes.INTEGER },
    attack: { type: DataTypes.INTEGER },
    defense: { type: DataTypes.INTEGER },
    special_attack: { type: DataTypes.INTEGER },
    special_defense: { type: DataTypes.INTEGER }
});

Pokemon.hasOne(Stat, { foreignKey: 'pokemon_id' });
Stat.belongsTo(Pokemon, { foreignKey: 'pokemon_id' });

module.exports = { sequelize, Pokemon, Stat };
