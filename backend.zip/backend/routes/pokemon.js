const express = require('express');
const router = express.Router();
const { Pokemon, Stat } = require('../models');

router.get('/pokemons', async (req, res) => {
    const { page = 1, limit = 10, type, name, sort } = req.query;

    let query = {};
    if (type) query.type = type;
    if (name) query.name = { [Op.iLike]: `%${name}%` };

    const pokemons = await Pokemon.findAndCountAll({
        where: query,
        limit,
        offset: (page - 1) * limit,
        order: sort ? [[sort, 'ASC']] : undefined
    });
    res.json(pokemons);
});

router.get('/pokemon/:id', async (req, res) => {
    const pokemon = await Pokemon.findByPk(req.params.id, {
        include: Stat
    });
    if (!pokemon) return res.status(404).json({ error: 'Pokemon not found' });
    res.json(pokemon);
});

router.get('/pokemon/:id/similar', async (req, res) => {
    const pokemon = await Pokemon.findByPk(req.params.id);
    if (!pokemon) return res.status(404).json({ error: 'Pokemon not found' });

    const similarPokemons = await Pokemon.findAll({
        where: { type: pokemon.type, id: { [Op.ne]: pokemon.id } }
    });
    res.json(similarPokemons);
});

module.exports = router;
