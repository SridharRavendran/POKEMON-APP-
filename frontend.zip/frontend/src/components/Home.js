import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

const Home = () => {
    const [pokemons, setPokemons] = useState([]);
    const [page, setPage] = useState(1);
    const [search, setSearch] = useState('');
    const [typeFilter, setTypeFilter] = useState('');

    const fetchPokemons = async () => {
        const response = await axios.get(`http://localhost:3000/api/pokemons`, {
            params: {
                page,
                name: search,
                type: typeFilter,
            },
        });
        setPokemons(response.data.rows);
    };

    useEffect(() => {
        fetchPokemons();
    }, [page, search, typeFilter]);

    return (
        <div>
            <h1>Pokémon List</h1>
            <input
                type="text"
                placeholder="Search Pokémon"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
            />
            <select
                onChange={(e) => setTypeFilter(e.target.value)}
                defaultValue=""
            >
                <option value="">Filter by Type</option>
                <option value="fire">Fire</option>
                <option value="water">Water</option>
                <option value="grass">Grass</option>
                {/* Add more types as needed */}
            </select>
            <ul>
                {pokemons.map((pokemon) => (
                    <li key={pokemon.id}>
                        <Link to={`/pokemon/${pokemon.id}`}>
                            <img src={pokemon.image} alt={pokemon.name} />
                            <p>
                                {pokemon.name} ({pokemon.type})
                            </p>
                        </Link>
                    </li>
                ))}
            </ul>
            <button onClick={() => setPage(page - 1)} disabled={page === 1}>
                Previous
            </button>
            <button onClick={() => setPage(page + 1)}>Next</button>
        </div>
    );
};

export default Home;
