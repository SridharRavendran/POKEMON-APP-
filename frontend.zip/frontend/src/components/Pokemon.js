import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';

const Pokemon = () => {
    const { id } = useParams();
    const [pokemon, setPokemon] = useState(null);
    const [similarPokemons, setSimilarPokemons] = useState([]);

    const fetchPokemon = async () => {
        const response = await axios.get(`http://localhost:3000/api/pokemon/${id}`);
        setPokemon(response.data);

        const similarResponse = await axios.get(
            `http://localhost:3000/api/pokemon/${id}/similar`
        );
        setSimilarPokemons(similarResponse.data);
    };

    useEffect(() => {
        fetchPokemon();
    }, [id]);

    if (!pokemon) return <div>Loading...</div>;

    return (
        <div>
            <h1>
                {pokemon.name} ({pokemon.type})
            </h1>
            <img src={pokemon.image} alt={pokemon.name} />
            <p>Height: {pokemon.height}</p>
            <p>Weight: {pokemon.weight}</p>
            <h2>Stats</h2>
            <ul>
                <li>HP: {pokemon.Stat.hp}</li>
                <li>Attack: {pokemon.Stat.attack}</li>
                <li>Defense: {pokemon.Stat.defense}</li>
                <li>Special Attack: {pokemon.Stat.special_attack}</li>
                <li>Special Defense: {pokemon.Stat.special_defense}</li>
            </ul>
            <h2>Similar Pokémon</h2>
            <ul>
                {similarPokemons.map((similarPokemon) => (
                    <li key={similarPokemon.id}>
                        <img src={similarPokemon.image} alt={similarPokemon.name} />
                        <p>
                            {similarPokemon.name} ({similarPokemon.type})
                        </p>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default Pokemon;
